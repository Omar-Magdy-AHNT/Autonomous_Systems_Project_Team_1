#!/usr/bin/env python3

import rospy

rospy.init_node('Validation_Printing_Node_Team_1')

print('Hello World From Team 1 Pi')
