#!/usr/bin/env python3
import rospy
import numpy as np
from geometry_msgs.msg import Pose2D, TwistStamped
from nav_msgs.msg import Odometry
import tf.transformations as tf_trans
import matplotlib.pyplot as plt
from threading import Lock

class KalmanFilter:
    def __init__(self, dt):
        self.dt = dt
        self.x = np.zeros((3, 1))  # [x, y, theta]
        self.P = np.eye(3) * 10  # Initial covariance
        self.Q = np.diag([0.05, 0.05, 0.025])
        self.R = np.diag([0.3, 0.3, 0.3])

    def predict(self, u):
        v, w = u
        theta = self.x[2, 0]



        
        # The Jacobian of the system model
        A = np.array([
            [1, 0, -v * np.sin(theta) * self.dt],
            [0, 1,  v * np.cos(theta) * self.dt],
            [0, 0, 1]
        ])

        B = np.array([
            [np.cos(theta) * self.dt, 0],
            [np.sin(theta) * self.dt, 0],
            [0, self.dt]
        ])

        self.x = A @ self.x + B @ np.array([[v], [w]])
        self.P = A @ self.P @ A.T + self.Q

    def update(self, z):
        C = np.eye(3)
        K = self.P @ C.T @ np.linalg.inv(C @ self.P @ C.T + self.R)

        self.x = self.x + K @ (z.reshape(3, 1) - C @ self.x)
        self.P = (np.eye(3) - K @ C) @ self.P

        return self.x.flatten()


class LocalizationNode:
    def __init__(self):
        rospy.init_node('Localization')
        self.dt = 0.01  # 20Hz
        self.kf = KalmanFilter(self.dt)
        self.initialized = False
        self.lock = Lock()

        # Noise
        self.noise_std = {
            'x': 0.2,
            'y': 0.2,
            'theta': 0.1,
            'v': 0.1,
            'omega': 0.05
        }

        self.latest_pose = Pose2D()
        self.v = 0.0
        self.omega = 0.0

        # Data for plotting
        self.true_states = []
        self.noisy_states = []
        self.filtered_states = []

        rospy.Subscriber('/odom', Odometry, self.odom_callback)
        rospy.Subscriber('/twist', TwistStamped, self.twist_callback)
        self.filtered_pub = rospy.Publisher('/filtered_pose', Pose2D, queue_size=10)
        self.filtered_twist_pub = rospy.Publisher('/twist_kf', TwistStamped, queue_size=10)
        self.filtered_odom_pub = rospy.Publisher('/odom_kf', Odometry, queue_size=10)

        rospy.Timer(rospy.Duration(self.dt), self.filter_step)
        rospy.on_shutdown(self.plot_results)

    def odom_callback(self, msg):
        pos = msg.pose.pose.position
        ori = msg.pose.pose.orientation
        orientation_q = [ori.x, ori.y, ori.z, ori.w]
        (_, _, yaw) = tf_trans.euler_from_quaternion(orientation_q)

        with self.lock:
            if not self.initialized:
                self.kf.x = np.array([[pos.x], [pos.y], [yaw]])
                self.initialized = True
                rospy.loginfo("Kalman Filter Initialized.")

            self.latest_pose.x = pos.x
            self.latest_pose.y = pos.y
            self.latest_pose.theta = yaw

    def twist_callback(self, msg):
        with self.lock:
            self.v = msg.twist.linear.x + np.random.normal(0, self.noise_std['v'])
            self.omega = msg.twist.angular.z + np.random.normal(0, self.noise_std['omega'])

    def filter_step(self, event):
        if not self.initialized:
            return

        with self.lock:
            # Add noise to measurements
            z = np.array([
                self.latest_pose.x + np.random.normal(0, self.noise_std['x']),
                self.latest_pose.y + np.random.normal(0, self.noise_std['y']),
                self.latest_pose.theta + np.random.normal(0, self.noise_std['theta'])
            ])

            self.kf.predict((self.v, self.omega))
            filtered_state = self.kf.update(z)

            # Publish filtered pose
            pose_msg = Pose2D()
            pose_msg.x, pose_msg.y, pose_msg.theta = filtered_state
            self.filtered_pub.publish(pose_msg)

            twist_msg = TwistStamped()
            twist_msg.twist.linear.x = self.v

            self.filtered_twist_pub.publish(twist_msg)
            

            # Save for plotting
            self.true_states.append([self.latest_pose.x, self.latest_pose.y, self.latest_pose.theta])
            self.noisy_states.append(z)
            self.filtered_states.append(filtered_state)

    def plot_results(self):
        true_states = np.array(self.true_states)
        noisy_states = np.array(self.noisy_states)
        filtered_states = np.array(self.filtered_states)

        labels = ['x', 'y', 'theta']
        for i in range(3):
            plt.figure()
            plt.plot(true_states[:, i], label='True')
            plt.plot(noisy_states[:, i], label='Noisy', alpha=0.6)
            plt.plot(filtered_states[:, i], label='Filtered', linestyle='--')
            plt.title(f"State: {labels[i]}")
            plt.xlabel("Time Step")
            plt.ylabel(labels[i])
            plt.legend()
            plt.grid(True)

        plt.show()

if __name__ == '__main__':
    try:
        LocalizationNode()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
