#!/usr/bin/env python3

import rospy
import math
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
from geometry_msgs.msg import Pose2D

class LateralController:
    def __init__(self):
        rospy.init_node('lateral_controller')

        rospy.Subscriber('/filtered_pose', Pose2D, self.odom_callback)
        rospy.Subscriber('/desired_lane', Float64, self.lane_callback)

        self.steering_pub = rospy.Publisher('/steering_cmd', Float64, queue_size=10)

        self.L = 2.65
        self.ld = 1.0
        self.currPose = None
        self.target_y = 1.5

        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            if self.currPose:
                steering_angle = self.pure_pursuit()
                self.steering_pub.publish(Float64(steering_angle))
                rospy.loginfo(f"Steering Angle: {steering_angle:.2f}")
            rate.sleep()

    def odom_callback(self, msg):
        self.currPose = msg

    def lane_callback(self, msg):
        self.target_y = msg.data

    def pure_pursuit(self):
        #curr_x = self.currPose.pose.pose.position.x
        curr_y = self.currPose.y
        curr_heading = self.currPose.theta

        dx = 6.0  # Lookahead forward in X
        dy = self.target_y - curr_y


        local_x = math.cos(-curr_heading)*dx - math.sin(-curr_heading)*dy
        local_y = math.sin(-curr_heading)*dx + math.cos(-curr_heading)*dy

        rospy.loginfo(f"error in y:{local_y}")

        if local_x == 0:
            return 0.0

        curvature = 2 * local_y / (self.ld ** 2)
        steering_angle = math.atan(self.L * curvature)
        return steering_angle

    def quat2euler(self, quat):
        siny_cosp = 2 * (quat.w * quat.z + quat.x * quat.y)
        cosy_cosp = 1 - 2 * (quat.y * quat.y + quat.z * quat.z)
        heading = math.atan2(siny_cosp, cosy_cosp)
        return heading

if __name__ == "__main__":
    try:
        LateralController()
    except rospy.ROSInterruptException:
        pass
