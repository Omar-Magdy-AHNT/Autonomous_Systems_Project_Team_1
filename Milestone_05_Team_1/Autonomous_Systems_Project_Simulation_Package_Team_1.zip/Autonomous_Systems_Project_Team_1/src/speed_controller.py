#!/usr/bin/env python3


import rospy

from geometry_msgs.msg import TwistStamped
from std_msgs.msg import Float64


class SpeedController:
    KP = 1.2  
    KI = 0.02 
    KD = 0.1 

    KP_BRAKE = 50

    def __init__(self):

        self.curr_speed = 0.0
        self.flag = False
        self.integral = 0.0
        self.prev_error = 0.0

        self.integral_brake = 0.0
        self.prev_error_brake = 0.0

        rospy.init_node('speed_controller')
        rospy.Subscriber('/twist', TwistStamped, self.twist_callback)

        throttle_pub = rospy.Publisher('/throttle_cmd', Float64, queue_size=10)
        brake_pub = rospy.Publisher('/brake_cmd', Float64, queue_size=10)

        #self.DESIRED = rospy.get_param('~desired_speed', 1.0)
        self.DESIRED = 0.0
        rospy.Subscriber('/desired_speed', Float64, self.desired_speed_callback)
    
        rate = rospy.Rate(10)
        prev_time = rospy.get_time()
    
        while not rospy.is_shutdown():
            curr_time = rospy.get_time()
            dt = curr_time - prev_time
            prev_time = curr_time

            if self.flag == True:
                throttle = self.PID(dt)
                throttle_pub.publish(Float64(throttle))
                
                brake = self.brake()
                brake_pub.publish(Float64(brake))

                #rospy.loginfo(f"Speed: {self.curr_speed:.2f} | Throttle: {throttle:.2f} | Brake:{brake:.2f}")
            rate.sleep()


    def twist_callback(self, msg):
        self.flag = True
        self.curr_speed = msg.twist.linear.x

    def desired_speed_callback(self, msg):
        self.DESIRED = msg.data

    def PID(self, dt):

        error = self.DESIRED - self.curr_speed
        #rospy.loginfo(f"error:{error}")

        self.integral += error*dt

        derivative = (error - self.prev_error) / dt if dt > 0 else 0.0

        output = self.KP * error + self.KI * self.integral + self.KD * derivative
        self.prev_error = error

        throttle = max(0.0, min(1.0, output))
        return throttle
    
    def brake(self):
        if self.DESIRED < self.curr_speed:
            brake = 100.0
        else:
            brake = 0.0
        return brake

    

    

if __name__ == '__main__':
    try:
        SpeedController()
    except rospy.ROSInterruptException:
        pass