#!/usr/bin/env python3

import rospy
import math
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64

class PositionController():
    def __init__(self):
        rospy.init_node('position_controller')

        self.lane_pub = rospy.Publisher('/desired_lane', Float64, queue_size=10)
        self.speed_pub = rospy.Publisher('/desired_speed', Float64, queue_size=10)

        rospy.Subscriber('/odom', Odometry, self.odom_callback)

        self.current_lane = 1.5  
        self.current_speed = 3.0  
  

    def odom_callback(self, msg):
        curr_x = msg.pose.pose.position.x

        if curr_x >= 0:
            self.current_lane = 1.5
            self.current_speed = 3.0

        if curr_x >= 10:
            self.current_speed = 6.0

        if curr_x >= 15:   
            self.current_speed = 3.0
            self.current_lane = -1.5

        if curr_x >= 30:
            self.current_speed = 6.0
        if curr_x > 47:
            self.current_lane = 1.5
            self.current_speed  = 3.0
        if curr_x > 55:
            self.current_speed = 6.0

        # Publish updated lane and speed
        self.lane_pub.publish(Float64(self.current_lane))
        self.speed_pub.publish(Float64(self.current_speed))
        rospy.loginfo(f"curr_x:{curr_x}")

if __name__ == "__main__":
    PositionController()
    rospy.spin()
