#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Pose2D
from std_msgs.msg import Float64

class PositionController():
    def __init__(self):
        rospy.init_node('position_controller')

        self.lane_pub = rospy.Publisher('/desired_lane', Float64, queue_size=10)
        self.speed_pub = rospy.Publisher('/desired_speed', Float64, queue_size=10)

        rospy.Subscriber('/arduino/pose', Pose2D, self.pose_callback)

        self.current_lane = 0.0 
        self.current_speed = 0.6

    def pose_callback(self, msg):
        curr_x = msg.x

        if curr_x < 1.0:
            self.current_lane = 0.0
            self.current_speed = 0.6
        elif curr_x < 2.0:
            self.current_lane = 1.5
            self.current_speed = 0.3
        elif curr_x < 4.0:
            self.current_lane = 1.5
            self.current_speed = 0.6
        elif curr_x < 5.0:
            self.current_lane = 0.0
            self.current_speed = 0.3
        elif curr_x < 7.0:
            self.current_lane = 0.0
            self.current_speed = 0.6
        elif curr_x < 7.5:
            self.current_lane = 1.5
            self.current_speed = 0.2
        elif curr_x < 8.0:
            self.current_lane = 0.0
        else:
            self.current_speed = 0.0  # Stop

        self.lane_pub.publish(Float64(self.current_lane))
        self.speed_pub.publish(Float64(self.current_speed))
        rospy.loginfo(f"curr_x: {curr_x:.2f}, lane: {self.current_lane}, speed: {self.current_speed}")

if __name__ == "__main__":
    PositionController()
    rospy.spin()
