#!/usr/bin/env python3
import rospy
import matplotlib.pyplot as plt
from geometry_msgs.msg import Pose2D, Twist
import numpy as np
from collections import deque

class StatePlotter:
    def __init__(self):
        rospy.init_node('vehicle_state_plotter')
        
        # Data storage with timestamps for each data type
        self.pose_data = {'time': [], 'x': [], 'y': [], 'theta': []}
        self.vel_data = {'time': [], 'vel': []}
        
        # Setup subscribers
        rospy.Subscriber('arduino/pose', Pose2D, self.pose_callback)
        rospy.Subscriber('arduino/velocity', Twist, self.velocity_callback)
        
        # Shutdown hook to plot when node stops
        rospy.on_shutdown(self.plot_data)

    def pose_callback(self, msg):
        current_time = rospy.get_time()
        self.pose_data['time'].append(current_time)
        self.pose_data['x'].append(msg.x)
        self.pose_data['y'].append(msg.y)
        self.pose_data['theta'].append(msg.theta * 180.0 / np.pi)  # Convert to degrees

    def velocity_callback(self, msg):
        current_time = rospy.get_time()
        self.vel_data['time'].append(current_time)
        self.vel_data['vel'].append(msg.linear.x)

    def plot_data(self):
        if not self.pose_data['time'] or not self.vel_data['time']:
            rospy.logwarn("Not enough data received to plot")
            return
            
        # Find common time range
        min_time = max(min(self.pose_data['time']), min(self.vel_data['time']))
        max_time = min(max(self.pose_data['time']), max(self.vel_data['time']))
        
        # Filter data to common time range
        pose_indices = [i for i, t in enumerate(self.pose_data['time']) 
                      if min_time <= t <= max_time]
        vel_indices = [i for i, t in enumerate(self.vel_data['time']) 
                     if min_time <= t <= max_time]
        
        # Get synchronized data
        pose_times = [self.pose_data['time'][i] for i in pose_indices]
        x_data = [self.pose_data['x'][i] for i in pose_indices]
        y_data = [self.pose_data['y'][i] for i in pose_indices]
        theta_data = [self.pose_data['theta'][i] for i in pose_indices]
        
        vel_times = [self.vel_data['time'][i] for i in vel_indices]
        vel_data = [self.vel_data['vel'][i] for i in vel_indices]
        
        # Convert to relative timestamps
        rel_pose_times = [t - min_time for t in pose_times]
        rel_vel_times = [t - min_time for t in vel_times]
        
        # Create figure with 4 subplots
        plt.figure(figsize=(12, 8))
        
        # Plot X Position
        plt.subplot(4, 1, 1)
        plt.plot(rel_pose_times, x_data, 'b-')
        plt.title('X Position')
        plt.ylabel('Meters')
        plt.grid(True)
        
        # Plot Y Position
        plt.subplot(4, 1, 2)
        plt.plot(rel_pose_times, y_data, 'g-')
        plt.title('Y Position')
        plt.ylabel('Meters')
        plt.grid(True)
        
        # Plot Heading
        plt.subplot(4, 1, 3)
        plt.plot(rel_pose_times, theta_data, 'r-')
        plt.title('Heading')
        plt.ylabel('Degrees')
        plt.grid(True)
        
        # Plot Velocity
        plt.subplot(4, 1, 4)
        plt.plot(rel_vel_times, vel_data, 'm-')
        plt.title('Velocity')
        plt.ylabel('m/s')
        plt.xlabel('Time (seconds)')
        plt.grid(True)
        
        # Adjust layout and show
        plt.tight_layout()
        plt.savefig('vehicle_states.png')  # Save to file
        plt.show()

if __name__ == '__main__':
    try:
        plotter = StatePlotter()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass