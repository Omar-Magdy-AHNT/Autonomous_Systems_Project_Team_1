#!/usr/bin/env python3

import rospy
import time
from geometry_msgs.msg import Twist, Pose2D
from std_msgs.msg import Float64

class SpeedController:
    KP = 0.6
    KI = 0.5
    KD = 0.01

    def __init__(self):
        rospy.init_node('real_speed_controller')

        rospy.Subscriber('/arduino/velocity', Twist, self.velocity_callback)
        rospy.Subscriber('/arduino/pose', Pose2D, self.pose_callback)
        rospy.Subscriber('/desired_speed', Float64, self.desired_speed_callback)

        self.throttle_pub = rospy.Publisher('/throttle_cmd', Float64, queue_size=1)

        self.desired_speed = 0.0
        self.curr_speed = 0.0
        self.prev_error = 0.0
        self.integral = 0.0
        self.curr_x = 0.0

        self.control_loop()

    def desired_speed_callback(self, msg):
        self.desired_speed = msg.data

    def control_loop(self):
        rate = rospy.Rate(50)
        prev_time = time.time()

        while not rospy.is_shutdown():
            now = time.time()
            dt = now - prev_time
            prev_time = now

            error = self.desired_speed - self.curr_speed
            self.integral += error * dt
            derivative = (error - self.prev_error) / dt if dt > 0 else 0.0

            pwm = self.KP * error + self.KI * self.integral + self.KD * derivative
            pwm = max(0.0, min(1.0, pwm))

            self.prev_error = error

            if self.desired_speed == 0.0:
                pwm = 0.0

            self.throttle_pub.publish(Float64(pwm))

            rospy.loginfo(f"[SpeedCtrl] Speed: {self.curr_speed:.2f}, Target: {self.desired_speed:.2f}, PWM: {pwm:.2f}, x: {self.curr_x:.2f}")
            rate.sleep()

    def velocity_callback(self, msg):
        self.curr_speed = msg.linear.x

    def pose_callback(self, msg):
        self.curr_x = msg.x

if __name__ == '__main__':
    try:
        SpeedController()
    except rospy.ROSInterruptException:
        pass
