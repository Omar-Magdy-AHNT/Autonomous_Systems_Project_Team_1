#!/usr/bin/env python3

import rospy
import serial
from geometry_msgs.msg import Pose2D, Twist, PoseStamped


def read_packet(ser):
    """Reads serial data between < and >"""
    packet = ''
    recording = False

    while True:
        if ser.in_waiting > 0:
            char = ser.read().decode('utf-8', errors='ignore')

            if char == '<':
                packet = ''
                recording = True
            elif char == '>':
                recording = False
                return packet.strip()
            elif recording:
                packet += char

def parse_line(line):
    """Parses a line like X:1.234,Y:5.678,Theta:90.0,V:0.500"""
    try:
        parts = line.strip().split(',')
        data = {}
        for part in parts:
            key, value = part.split(':')
            data[key.strip()] = float(value.strip())
        return data['X'], data['Y'], data['Theta'], data['V']
    except Exception as e:
        rospy.logwarn("Failed to parse line: {} Error: {}".format(line, e))
        return None

def main():
    rospy.init_node('arduino_localization_node')

    # Params (can be overridden via launch file)
    serial_port = rospy.get_param('~port', '/dev/ttyACM0')
    baudrate = rospy.get_param('~baudrate', 115200)

    vel_prev = 0.0

    # ROS Publishers
    pose_pub = rospy.Publisher('arduino/pose', Pose2D, queue_size=10)
    vel_pub = rospy.Publisher('arduino/velocity', Twist, queue_size=10)

    # Open serial connection
    try:
        ser = serial.Serial(serial_port, baudrate, timeout=1)
        rospy.loginfo("Opened serial port: {}".format(serial_port))
    except serial.SerialException:
        rospy.logerr("Failed to open serial port: {}".format(serial_port))
        return

    rate = rospy.Rate(100)  # 30 Hz loop

    while not rospy.is_shutdown():
        try:
            if ser.in_waiting > 0:
                packet = read_packet(ser)
                if packet:
                    parsed = parse_line(packet)
                    if parsed:
                        x, y, theta, v = parsed

                        #if v==0:
                        #    v = vel_prev
                        #vel_prev = v

                        # Create Pose2D message
                        #pose_msg = PoseStamped()
                        #pose_msg.header.stamp = rospy.Time.now()
                        #pose_msg.header.frame_id = "Odom"
                        #pose_msg.pose.position.x = x
                        #pose_msg.pose.position.y = y
                        #pose_msg.pose.position.z = 0

                        #quaternion = tf.transformations.quaternion_from_euler(0, 0, theta * 3.14159 / 180.0)
                        #pose_msg.pose.orientation.x = quaternion[0]
                        #pose_msg.pose.orientation.y = quaternion[1]
                        #pose_msg.pose.orientation.z = quaternion[2]
                        #pose_msg.pose.orientation.w = quaternion[3]

                        pose_msg = Pose2D()
                        pose_msg.x = x
                        pose_msg.y = y
                        pose_msg.theta = theta


                        # Create Twist message
                        vel_msg = Twist()
                        vel_msg.linear.x = v
                        vel_msg.linear.y = 0.0
                        vel_msg.angular.z = 0.0  # No angular velocity info

                        # Publish
                        pose_pub.publish(pose_msg)
                        vel_pub.publish(vel_msg)
        except serial.SerialException as e:
            rospy.logerr("Serial Exception: {}".format(e))
            break
        except rospy.ROSInterruptException:
            break

        rate.sleep()

if __name__ == '__main__':
    main()
