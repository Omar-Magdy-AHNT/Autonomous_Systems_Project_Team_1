#!/usr/bin/env python3

import rospy
import math
from std_msgs.msg import Float64
from geometry_msgs.msg import Pose2D, Twist

class LateralController:
    def __init__(self):
        rospy.init_node('lateral_controller')

        rospy.Subscriber('/arduino/pose', Pose2D, self.pose_callback)
        rospy.Subscriber('/arduino/velocity', Twist, self.velocity_callback)
        rospy.Subscriber('/desired_lane', Float64, self.lane_callback)

        self.steering_pub = rospy.Publisher('/steering_cmd', Float64, queue_size=1)

        self.curr_x = 0.0
        self.curr_y = 0.0
        self.curr_heading = 0.0
        self.target_y = 0.0  # Default

        self.prev_steering = 0.0
        self.steering_filter_gain = 0.2

        self.curr_speed = 0.0

        self.k = 0.9

        rate = rospy.Rate(50)
        while not rospy.is_shutdown():
            steering_angle = self.stanley()
            self.steering_pub.publish(Float64(steering_angle))
            rospy.loginfo(f"[Lateral] Steering Angle: {steering_angle:.2f}")
            rate.sleep()

    def pose_callback(self, msg):
        self.curr_x = msg.x
        self.curr_y = msg.y
        self.curr_heading = msg.theta

    def lane_callback(self, msg):
        self.target_y = msg.data

    def velocity_callback(self, msg):
        self.curr_speed = msg.linear.x

    def stanley(self):
        cte = self.target_y - self.curr_y

        rospy.loginfo(f"CTE:{cte}")

        #heading_error = math.atan2(math.sin(-self.curr_heading), math.cos(-self.curr_heading))
        heading_error = -self.curr_heading
        self.curr_speed = max(0.1, self.curr_speed)

        steering = 0.05*heading_error + math.atan2(self.k*cte, self.curr_speed)

        steering = max(-1.0, min(1.0, steering))



        #filtered_steering = (1.0 - self.steering_filter_gain) * self.prev_steering + self.steering_filter_gain * steering
        #self.prev_steering = filtered_steering
        
        
        return steering

if __name__ == "__main__":
    try:
        LateralController()
    except rospy.ROSInterruptException:
        pass
