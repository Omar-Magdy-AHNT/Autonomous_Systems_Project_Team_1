#!/usr/bin/env python3

import rospy
import serial
from std_msgs.msg import Float64

class CommandSender:
    def __init__(self):
        rospy.init_node('arduino_command_sender')

        # Serial port parameters
        serial_port = rospy.get_param('~port', '/dev/ttyACM1')
        baudrate = rospy.get_param('~baudrate', 115200)

        try:
            self.ser = serial.Serial(serial_port, baudrate, timeout=1)
            rospy.loginfo(f"[Serial] Connected to {serial_port} at {baudrate} baud")
        except serial.SerialException as e:
            rospy.logerr(f"[Serial] Failed to connect: {e}")
            raise e

        self.throttle = 0.0
        self.steering = 0.0

        rospy.Subscriber('/throttle_cmd', Float64, self.throttle_callback)
        rospy.Subscriber('/steering_cmd', Float64, self.steering_callback)

        self.loop()

    def throttle_callback(self, msg):
        self.throttle = msg.data

    def steering_callback(self, msg):
        self.steering = msg.data

    def loop(self):
        rate = rospy.Rate(50)  # 50 Hz
        while not rospy.is_shutdown():
            try:
                command = f"T:{self.throttle:.3f}\nS:{self.steering:.3f}\n"
                self.ser.write(command.encode('utf-8'))
                rospy.logdebug(f"[TX] {command.strip()}")
            except serial.SerialException as e:
                rospy.logerr(f"[Serial Write Error] {e}")
            rate.sleep()


if __name__ == "__main__":
    try:
        CommandSender()
    except rospy.ROSInterruptException:
        pass