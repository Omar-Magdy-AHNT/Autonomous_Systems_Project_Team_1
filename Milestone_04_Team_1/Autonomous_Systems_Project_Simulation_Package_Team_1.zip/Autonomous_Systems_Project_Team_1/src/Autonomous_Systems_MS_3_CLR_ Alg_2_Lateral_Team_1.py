#!/usr/bin/env python3


import rospy
import math

from nav_msgs.msg import Odometry
from std_msgs.msg import Float64

class LateralController:
    def __init__(self):
        rospy.init_node('lateral_controller')
        rospy.Subscriber('/odom', Odometry, self.odom_callback)

        steering_publisher = rospy.Publisher('/steering_cmd', Float64, queue_size=10)

        self.L = 2.65
        self.ld = 10.0

        self.currPose = None

        self.goal_x = rospy.get_param('~goalX', 50)
        self.goal_y = rospy.get_param('~goalY', 50)

        self.goalPose = [self.goal_x, self.goal_y]

        rate = rospy.Rate(10)
        
        while not rospy.is_shutdown():
            if self.currPose:
                steering_angle = self.pure_pursuit()
                steering_publisher.publish(Float64(steering_angle))
                rospy.loginfo(f"Steering Angle: {steering_angle:.2f}")
            rate.sleep()


    def odom_callback(self, msg):
        self.currPose = msg

    def pure_pursuit(self):

        
        curr_x = self.currPose.pose.pose.position.x
        curr_y = self.currPose.pose.pose.position.y
        curr_heading = self.quat2euler(self.currPose.pose.pose.orientation)

        target_x = self.goalPose[0]
        target_y = self.goalPose[1]

        dx = target_x - curr_x
        dy = target_y - curr_y

        local_x = math.cos(-curr_heading)*dx - math.sin(-curr_heading)*dy
        local_y = math.sin(-curr_heading)*dx + math.cos(-curr_heading)*dy

        if local_x == 0:
            return 0.0
        
        curvature = 2 * local_y / (self.ld**2)
        steering_angle = math.atan(self.L * curvature)


        return steering_angle

    
    def quat2euler(self, quat):

        siny_cosp = 2 * (quat.w * quat.z + quat.x * quat.y)
        cosy_cosp = 1 - 2 * (quat.y * quat.y + quat.z * quat.z)

        heading = math.atan2(siny_cosp, cosy_cosp)

        return heading
    
if __name__ == "__main__":
    try:
        LateralController()
    except rospy.ROSInterruptException:
        pass