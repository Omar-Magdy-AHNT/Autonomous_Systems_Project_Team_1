#!/usr/bin/env python3

import rospy
import time
import serial

from geometry_msgs.msg import Twist, Pose2D

class SpeedController:
    # PID constants
    KP = 0.7
    KI = 0.3
    KD = 0.01

    def __init__(self):
        rospy.init_node('real_speed_controller')

        serial_port = rospy.get_param('~port', '/dev/ttyACM0')
        baudrate = rospy.get_param('~baudrate', 115200)

        try:
            self.ser = serial.Serial(serial_port, baudrate, timeout=1)
            rospy.loginfo(f"Opened serial port: {serial_port}")
        except serial.SerialException as e:
            rospy.logerr(f"Failed to open serial port: {e}")
            raise e

        rospy.Subscriber('/arduino/velocity', Twist, self.velocity_callback)
        rospy.Subscriber('/arduino/pose', Pose2D, self.pose_callback)

        # Desired speed in m/s
        self.desired_speed = rospy.get_param('~desired_speed', 0.35)

        # Internal PID state
        self.curr_speed = 0.0
        self.prev_error = 0.0
        self.integral = 0.0

        self.curr_x = 0.0
        self.curr_y = 0.0

        # Start control loop
        self.control_loop()

    def control_loop(self):
        rate = rospy.Rate(50) 
        prev_time = time.time()

        while not rospy.is_shutdown():
            now = time.time()
            dt = now - prev_time
            prev_time = now

            error = self.desired_speed - self.curr_speed
            self.integral += error * dt
            derivative = (error - self.prev_error) / dt if dt > 0 else 0.0

            pwm = self.KP * error + self.KI * self.integral + self.KD * derivative
            pwm = max(0.0, min(1.0, pwm))  # Clamp between 0 and 1

            self.prev_error = error

            steering = 0

            if self.curr_x >= 2.0 and self.curr_x <= 4.0:
                self.send_pwm(pwm, 1)
            elif self.curr_x > 4.0:
                self.send_pwm(0, 0) ##### check here
            else:
                self.send_pwm(pwm, 0)

            rospy.loginfo("[PID] Desired: {:.2f} | Current: {:.2f} | PWM: {:.2f} | curr_x: {:.2f} | Steering:{}".format(
                self.desired_speed, self.curr_speed, pwm, self.curr_x, steering))
            


            rate.sleep()

    def velocity_callback(self, msg):
        """Get current speed from Twist message."""
        self.curr_speed = msg.linear.x 

    def pose_callback(self, msg):
        pose_msg = msg
        self.curr_x = pose_msg.x
        self.curr_y = pose_msg.y

    def send_pwm(self, pwm, steering):
        """Send PWM command to Arduino in format: P:<value>"""
        try:
            command = f"P:{pwm},S:{steering}\n"
            self.ser.write(command.encode())
        except Exception as e:
            rospy.logerr(f"Failed to send PWM: {e}")

if __name__ == '__main__':
    try:
        SpeedController()
    except rospy.ROSInterruptException:
        pass
