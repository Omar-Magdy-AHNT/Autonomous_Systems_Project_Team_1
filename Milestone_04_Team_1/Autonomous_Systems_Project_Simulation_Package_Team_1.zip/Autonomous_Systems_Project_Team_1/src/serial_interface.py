#!/usr/bin/env python3

import rospy
import serial

from std_msgs.msg import Float64

class SerialInterfaceNode:
    def __init__(self):
        rospy.init_node('serial_interface_node')

        self.ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
        rospy.loginfo("Connected to Arduino")

        self.throttle = 0.0
        self.steering = 0.0

        rospy.Subscriber('/throttle_cmd', Float64, self.throttle_callback)
        rospy.Subscriber('/steering_cmd', Float64, self.steering_callback)

        rate = rospy.Rate(10)
        
        while not rospy.is_shutdown():
            self.send_serial()
            rate.sleep()

    def throttle_callback(self, msg):
        self.throttle = msg.data

    def steering_callback(self, msg):
        self.steering = msg.data


    def send_serial(self):
        command = f"T:{self.throttle:.2f},S:{self.steering:.2f}\n"
        try:
            self.ser.write(command.encode('utf-8'))
            rospy.loginfo(f"Sent: {command.strip()}")
        except serial.SerialException as e:
            rospy.logerr(f"serial error: {e}")

if __name__ == "__main__":
    SerialInterfaceNode()