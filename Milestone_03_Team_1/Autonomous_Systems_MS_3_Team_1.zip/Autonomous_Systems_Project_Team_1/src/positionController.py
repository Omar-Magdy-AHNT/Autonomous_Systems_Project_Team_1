#!/usr/bin/env python3

import rospy
import math

from nav_msgs.msg import Odometry
from std_msgs.msg import Float64

class PositionController():
    def __init__(self):
        rospy.init_node('position_controller')


        self.goal_x = rospy.get_param('~goalX', 50)
        self.goal_y = rospy.get_param('~goalY', 50)
        self.goal = [self.goal_x, self.goal_y]

        self.max_speed = 5.0
        self.min_speed = 0.05

        self.desired_speed_pub = rospy.Publisher('/desired_speed', Float64, queue_size=10)
        rospy.Subscriber('/odom', Odometry, self.odom_callback)

    def odom_callback(self, msg):
        curr_x = msg.pose.pose.position.x
        curr_y = msg.pose.pose.position.y

        distance = math.hypot(self.goal[0] - curr_x, self.goal[1] - curr_y)

        if distance > 45.0:
            speed = self.max_speed
        elif distance > 20.0:
            #speed = self.min_speed + (self.max_speed - self.min_speed) * (distance / 40.0)
            speed = 3.5
        elif distance > 10.0:
            speed = 2.5
        elif distance > 1.0:
            speed = 0.7
        else:
            speed = 0.0
        self.desired_speed_pub.publish(Float64(speed))
        rospy.loginfo("--------------------------------------------------")
        rospy.loginfo(f"Goal:{self.goal[0]},{self.goal[1]} | Current:{curr_x}, {curr_y}")
        rospy.loginfo(f"Distance to goal: {distance:.2f}, Desired Speed: {speed:.2f}")

if __name__ == "__main__":
    PositionController()
    rospy.spin()