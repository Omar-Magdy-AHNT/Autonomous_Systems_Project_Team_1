#!/usr/bin/env python3

import rospy
import serial
import time


class SpeedController:
    # PID constants
    KP = 0.7
    KI = 0.3
    KD = 0.01

    def __init__(self):
        rospy.init_node('real_speed_controller')

        # Open serial connection to Arduino
        self.ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
        time.sleep(2)
        rospy.loginfo("Serial connection established with Arduino")

        # Desired speed in m/s (hardcoded)
        self.desired_speed = 0.7

        # Internal state
        self.curr_speed = 0.0
        self.prev_error = 0.0
        self.integral = 0.0
        self.last_speed_time = time.time()

        rate = rospy.Rate(10)
        prev_time = time.time()

        while not rospy.is_shutdown():
            now = time.time()
            dt = now - prev_time
            prev_time = now

            self.read_speed()

            error = self.desired_speed - self.curr_speed
            self.integral += error * dt
            derivative = (error - self.prev_error) / dt if dt > 0 else 0.0

            pwm = self.KP * error + self.KI * self.integral + self.KD * derivative
            pwm = max(0.0, min(1.0, pwm))
            self.prev_error = error

            self.send_pwm(pwm)

            rospy.loginfo(f"[PID] Desired: {self.desired_speed:.2f} | Current: {self.curr_speed:.2f} | PWM: {pwm}")
            rate.sleep()

    def read_speed(self):
        try:
            if self.ser.in_waiting > 0:
                line = self.ser.readline().decode().strip()
                if line.startswith("S:"):
                    self.curr_speed = float(line[2:])
                    self.last_speed_time = time.time()
        except Exception as e:
            rospy.logwarn(f"Failed to read speed: {e}")

        # Timeout check — if no update in 0.5s, assume speed is 0
        if time.time() - self.last_speed_time > 0.5:
            self.curr_speed = 0.0

    def send_pwm(self, value):
        """Send PWM to Arduino in format: P:123"""
        try:
            command = f"P:{value}\n"
            self.ser.write(command.encode())
        except Exception as e:
            rospy.logerr(f"Failed to send PWM: {e}")


if __name__ == '__main__':
    try:
        SpeedController()
    except rospy.ROSInterruptException:
        pass
